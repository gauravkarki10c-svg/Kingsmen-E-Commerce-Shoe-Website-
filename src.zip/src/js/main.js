// Form validation function
function validateForm() {
  let isValid = true;

  // Validate full name field
  const fullName = document.getElementById("fullName").value.trim();
  if (fullName === "") {
    document.getElementById("nameError").style.display = "block";
    isValid = false;
  } else {
    document.getElementById("nameError").style.display = "none";
  }

  // Validate gender selection
  const genderMale = document.getElementById("male").checked;
  const genderFemale = document.getElementById("female").checked;
  if (!genderMale && !genderFemale) {
    document.getElementById("genderError").style.display = "block";
    isValid = false;
  } else {
    document.getElementById("genderError").style.display = "none";
  }

  // Validate message field
  const message = document.getElementById("message").value.trim();
  if (message === "") {
    document.getElementById("messageError").style.display = "block";
    isValid = false;
  } else {
    document.getElementById("messageError").style.display = "none";
  }

  // Show success message and reset form if valid
  if (isValid) {
    alert("Thank you for your message! We will get back to you soon.");
    document.getElementById("contactForm").reset();
  }

  return false;
}
